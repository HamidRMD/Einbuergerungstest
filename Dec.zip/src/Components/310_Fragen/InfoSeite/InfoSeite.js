import React from 'react';
import "../FragenSeite/style_1.css";

const Info =()=>{
      return <div className={"FragenStyle"}>
            
<h1 className={"text"}>Info Seite</h1>
      </div>
}
export default Info;