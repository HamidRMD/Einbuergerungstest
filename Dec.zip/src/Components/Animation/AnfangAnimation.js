import './AnfangAnimation.css';
const AnfangAnimation = () => {
    return (
        <div>
        <h1 className="LogoName">WorldCode</h1>
        <div className="backgroundNachOben"> </div>

        </div>

    )
}

export default AnfangAnimation