# Einbuergerungstest
Abschlussprojekt

# Team

Hamid, Khaled, Anderson, Elahe, Jakob

## Beispiel: Die Vorlage für die Startseite von Anderson und Jakob.
![Screenshot from 2021-03-31 20-12-51](https://user-images.githubusercontent.com/61413894/113191747-32b16600-925e-11eb-9740-e662aa12a124.png)


## Beispiel: Die Vorlage für die Über uns Startseite von Jakob.
![Screenshot from 2021-03-31 20-13-29](https://user-images.githubusercontent.com/61413894/113191792-4361dc00-925e-11eb-9634-b512a29ed8cb.png)


## Beispiel: Die Vorlage von dem Login von Jakob.
![Screenshot from 2021-03-31 16-23-26](https://user-images.githubusercontent.com/61413894/113160856-261d1580-923e-11eb-956e-73b2df588a6a.png)

## Beispiel: Die Vorlage von der Registrierung von Jakob.
![Screenshot from 2021-03-31 20-12-59](https://user-images.githubusercontent.com/61413894/113191912-6a201280-925e-11eb-88f8-6835df8ff8d6.png)


## Beispiel: Die Seite mit der Fragen von dem Quiz von Jakob.
![Screenshot from 2021-03-31 15-24-04](https://user-images.githubusercontent.com/61413894/113151345-45637500-9235-11eb-8ff6-f66693f4b5a7.png)


## Beispiel: Die Seite mit der Fragen von dem Quiz,wenn man falsch beantwortet hat.By Jakob.
![Screenshot from 2021-04-01 10-49-52](https://user-images.githubusercontent.com/61413894/113269227-8791c280-92d8-11eb-80cf-23d621fc0600.png)

## Wenn man eine Frage beim Quiz richtig beantwortet hat.By Jakob.
![Screenshot from 2021-03-31 20-13-14](https://user-images.githubusercontent.com/61413894/113191948-74daa780-925e-11eb-89b1-90b606218aa7.png)


## Seite mit den 310 Fragen.By Elahe, Kahled und unterschtüzung von Jakob.
![Screenshot from 2021-04-01 09-54-31](https://user-images.githubusercontent.com/61413894/113263153-b6586a80-92d1-11eb-8082-8b9b049873c1.png)
![Screenshot from 2021-03-31 15-55-18](https://user-images.githubusercontent.com/61413894/113161970-279b0d80-923f-11eb-97be-1955d15a5fee.png)
![Screenshot from 2021-03-31 15-49-02](https://user-images.githubusercontent.com/61413894/113161320-8f048d80-923e-11eb-8bea-d9da2830389c.png)
![Screenshot from 2021-04-01 10-14-04](https://user-images.githubusercontent.com/61413894/113264433-434ff380-92d3-11eb-861b-901c804f3959.png)


## Das Testergebnis von Elahe und Jakob.
![Screenshot from 2021-04-01 09-54-41](https://user-images.githubusercontent.com/61413894/113263191-c07a6900-92d1-11eb-94a6-d01dc210b1b0.png)

## Das Testergebnis von Elahe und Jakob.
![Screenshot from 2021-04-01 09-54-45](https://user-images.githubusercontent.com/61413894/113263211-c708e080-92d1-11eb-85c0-5792172db017.png)


## PLAN
![Planung](https://user-images.githubusercontent.com/65950252/112838376-4a8dbc00-909d-11eb-8951-f87a8ead9f96.jpg)




